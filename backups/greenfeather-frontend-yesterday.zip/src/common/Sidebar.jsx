import React from 'react'

const Sidebar = () => {
  return (
    <div>
      this is sidebar
    </div>
  )
}

export default Sidebar
